from django.conf.urls import url
from basic_app.views import register,index,user_login
app_name ='basic_app'
urlspatterens=[
    ]
